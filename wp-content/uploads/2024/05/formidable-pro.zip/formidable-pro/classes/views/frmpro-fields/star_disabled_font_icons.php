<?php
if ( ! defined( 'ABSPATH' ) ) {
	die( 'You are not allowed to call this page directly.' );
}
_deprecated_file( basename( __FILE__ ), '6.6' );
